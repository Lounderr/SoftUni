﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Renovators
{
    public class Catalog
    {
        private List<Renovator> renovators;

        public Catalog(string name, int neededRenovators, string project)
        {
            Name = name;
            NeededRenovators = neededRenovators;
            Project = project;

            renovators = new List<Renovator>();
        }

        private string Name { get; set; }

        private int NeededRenovators { get; set; }

        private string Project { get; set; }

        public int Count { get => renovators.Count; }


        public string AddRenovator(Renovator renovator)
        {
            if (NeededRenovators > renovators.Count)
                if (renovator.Name != null && renovator.Name != "")
                    if (renovator.Rate <= 350)
                    {
                        renovators.Add(renovator);
                        return $"Successfully added {renovator.Name} to the catalog.";
                    }
                    else
                        return "Invalid renovator's rate.";
                else
                    return $"Invalid renovator's information.";
            else
                return $"Renovators are no more needed.";
        }

        public bool RemoveRenovator(string name)
        {
            if (renovators.Any(r => r.Name == name))
            {
                Renovator renovator = renovators.Where(r => r.Name == name).First();
                renovators.Remove(renovator);
                return true;
            }

            return false;
        }

        public int RemoveRenovatorBySpecialty(string type)
        {
            int removedCount = 0;
            foreach (var renovator in renovators.ToList())
            {
                if (renovator.Type == type)
                {
                    renovators.Remove(renovator);
                    removedCount++;
                }
            }

            return removedCount;
        }

        public Renovator HireRenovator(string name)
        {
            for (int i = 0; i < renovators.Count; i++)
            {
                if (renovators[i].Name == name)
                {
                    renovators[i].Hired = true;
                    return renovators[i];
                }
            }

            return null;
        }

        public List<Renovator> PayRenovators(int days)
        {
            return renovators.Where(r => r.Days >= days).ToList();
        }

        public string Report()
        {
            StringBuilder output = new StringBuilder();
            output.AppendLine($"Renovators available for Project {Project}:");
            foreach (var renovator in renovators.Where(r => r.Hired == false))
            {
                output.AppendLine(renovator.ToString());
            }

            return output.ToString();
        }

    }
}
